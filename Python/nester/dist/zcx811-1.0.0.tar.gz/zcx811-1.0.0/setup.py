from distutils.core import setup

setup(
		name			= 'zcx811',
		version			= '1.0.0',
		py_modules		= ['nester'],
		author			= 'hfpython',
		author_email	= 'hfpython@headfirstlabs.com',
		url				= 'http://www.headfirstlabs.com',
		description		= 'A simples printer of nested lists',
	 )